﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chess
{
    public partial class ChessOkno : Form
    {
        public ChessOkno()
        {
            InitializeComponent();
        }

        int sirka = 0;
        List<Color> farby = new List<Color>() { Color.Black, Color.White };
        List<int> sachovnica = new List<int>() { };

        List<Figurka> figurky = new List<Figurka>() { };

        int startX = 0;
        int startY = 0;

        bool active = false;
        int aktivnaFigurka = 0;
        int aktivnaPozicia = 0;



        public void vykreslenie()
        {
            vykresleniePlochy();
            vykreslenieFiguriek();
        }

        public void vykresleniePlochy()
        {
            panelHraciaPlocha.Width = Size.Width - 16;
            panelHraciaPlocha.Height = Size.Height - 39;

            Graphics graphics = panelHraciaPlocha.CreateGraphics();
            graphics.Clear(SystemColors.Control);

            if (panelHraciaPlocha.Width == panelHraciaPlocha.Height)
                sirka = panelHraciaPlocha.Width / 8;
            else
            {
                if (panelHraciaPlocha.Width < panelHraciaPlocha.Height)
                    sirka = panelHraciaPlocha.Width / 8;
                else
                    sirka = panelHraciaPlocha.Height / 8;
            }


            int x = (panelHraciaPlocha.Width / 2) - 4 * sirka;
            int y = (panelHraciaPlocha.Height / 2) - 4 * sirka;
            startX = x;
            startY = y;


            int p = 0;
            for (int m = 0; m < 8; m++)
            {
                for (int n = 0; n < 8; n++)
                {
                    graphics.FillRectangle(new SolidBrush(farby[p % 2]), x, y, sirka, sirka);
                    p++;
                    x += sirka;
                }
                p++;
                x = startX;
                y += sirka;

            }
        }

        public void vykreslenieFiguriek()
        {
            Graphics graphics = panelHraciaPlocha.CreateGraphics();

            int x = startX;
            int y = startY;

            int p = 0;
            for (int m = 0; m < 8; m++)
            {
                for (int n = 0; n < 8; n++)
                {
                    if (sachovnica[p] != -1)
                    {
                        graphics.FillRectangle(new SolidBrush(Color.Aqua), x + 5, y + 5, sirka - 10, sirka - 10);
                    }

                    x += sirka;
                    p++;
                }
                x = startX;
                y += sirka;
            }
        }

        public void vytvorenieFiguriek()
        {
            for (int i = 0; i < 64; i++)
            {
                sachovnica.Add(-1);
            }

            figurky.Add(new Figurka(50, 0, "p"));
            figurky.Add(new Figurka(45, 0, "h"));
            figurky.Add(new Figurka(30, 0, "s"));
            figurky.Add(new Figurka(61, 0, "v"));
            figurky.Add(new Figurka(5, 0, "d"));

            int p = 0;
            foreach (Figurka figurka in figurky)
            {
                sachovnica[figurka.pozicia] = p;
                p++;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Console.WriteLine(sachovnica.Count);
            vykresleniePlochy();
            vytvorenieFiguriek();
            vykreslenieFiguriek();
        }

        private void Form1_SizeChanged(object sender, EventArgs e)
        {
            vykreslenie();
        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        public int zisteniePozicie(int x, int y)
        {
            int xx = startX;
            int yy = startY;
            int p = 0;

            for (int m = 0; m < 8; m++)
            {
                for (int n = 0; n < 8; n++)
                {
                    if (x >= xx && y >= yy && x <= xx + sirka && y <= yy + sirka)
                        return p;
                    xx += sirka;
                    p++;
                }
                xx = startX;
                yy += sirka;
            }
            return -1;
        }

        private void panelHraciaPlocha_MouseClick(object sender, MouseEventArgs e)
        {
            int zistenaPozicia = zisteniePozicie(e.X, e.Y);
            Console.WriteLine(zistenaPozicia);
            if (zistenaPozicia != -1)
            {
                Console.WriteLine("AAAA");
                if (!active && sachovnica[zistenaPozicia] != -1)
                {
                    active = true;
                    aktivnaFigurka = sachovnica[zistenaPozicia];
                    aktivnaPozicia = zistenaPozicia;
                }
                else
                {
                    if (active)
                    {
                        active = false;
                        if (figurky[aktivnaFigurka].ZisteniePohybu(zistenaPozicia))
                        {
                            sachovnica[aktivnaPozicia] = -1;
                            sachovnica[zistenaPozicia] = aktivnaFigurka;
                            figurky[aktivnaFigurka].pozicia = zistenaPozicia;
                        }
                        
                    }
                }
            }
            foreach(int a in sachovnica)
            {
                Console.WriteLine("LLL -- " + a);
            }
            Console.WriteLine(active);
            vykreslenie();
        }

        private void panelHraciaPlocha_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
