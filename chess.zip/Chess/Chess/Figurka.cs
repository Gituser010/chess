﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chess
{
    class Figurka
    {
        public int pozicia, farba;
        public string typ;
        public Figurka(int pozicia, int farba, string typ)
        {
            this.pozicia = pozicia;
            this.farba = farba;
            this.typ = typ;
        }

        public bool ZisteniePohybu(int index)
        {

            if (typ == "p") //pešiak
            {
                if (farba == 0)
                {
                    if (pozicia >= 48 && pozicia <= 55)
                    {
                        if (index + 16 == pozicia)
                            return true;
                    }
                    if (index + 8 == pozicia)
                        return true;
                }
                if (farba == 1)
                {
                    if (pozicia >= 8 && pozicia <= 15)
                    {
                        if (index - 16 == pozicia)
                            return true;
                    }
                    if (index - 8 == pozicia)
                        return true;
                }
                return false;
                                       
            }

            if (typ == "s") //strelec
            {

                if ((index - pozicia) % 7 == 0 || (index - pozicia) % 9 == 0 || (pozicia - index) % 7 == 0 || (pozicia - index) % 9 == 0)//pohyb šikmo
                    return true;

                else
                    return false;
            }
            if (typ == "v") //veža
            {
                int pocetPoliVlavo = pozicia % 8;

                if ((pocetPoliVlavo >= pozicia - index && pozicia - index < 8 && pozicia - index >= 0) || (7 - pocetPoliVlavo >= index - pozicia && index - pozicia < 8 && index - pozicia >= 0))// pohyb do ľava/prava
                    return true;
                else
                {
                    if ((index - pozicia) % 8 == 0 || (pozicia - index) % 8 == 0)//pohyb hore/dole
                        return true;
                    else
                        return false;
                }
               
            }
            if (typ == "d") //dáma
            {
                int pocetPoliVlavo = pozicia % 8;

                if ((pocetPoliVlavo >= pozicia - index && pozicia - index < 8 && pozicia - index >= 0) || (7 - pocetPoliVlavo >= index - pozicia && index - pozicia < 8 && index - pozicia >= 0))// pohyb do ľava/prava
                    return true;
                else
                {
                    if ((index - pozicia) % 8 == 0 || (pozicia - index) % 8 == 0)//pohyb hore/dole
                        return true;
                    else
                    {
                        if ((index - pozicia) % 7 == 0 || (index - pozicia) % 9 == 0 || (pozicia - index) % 7 == 0 || (pozicia - index) % 9 == 0)//pohyb šikmo
                            return true;
                        else
                            return false;
                    }

                }
            }
            if (typ == "h")
            {
                if ((index - pozicia) % 8 == 0 || (index - pozicia) % 9 == 0)
                    return false;
                else
                {
                    if ((index - pozicia) / 6 == 1 || (index - pozicia) / 15 == 1 || (pozicia - index) / 17 == 1 || (pozicia - index) / 10 == 1)//pohyb kôň ľava
                        return true;
                    else
                    {
                        if ((pozicia - index) / 6 == 1 || (pozicia - index) / 15 == 1 || (index - pozicia) / 17 == 1 || (index - pozicia) / 10 == 1)//pohyb kôň pravá
                            return true;
                        else
                            return false;
                    }
                }
            }
            return false;
        }
    }
}
