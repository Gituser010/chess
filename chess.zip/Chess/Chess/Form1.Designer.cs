﻿namespace Chess
{
    partial class ChessOkno
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelHraciaPlocha = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // panelHraciaPlocha
            // 
            this.panelHraciaPlocha.Location = new System.Drawing.Point(0, 0);
            this.panelHraciaPlocha.Name = "panelHraciaPlocha";
            this.panelHraciaPlocha.Size = new System.Drawing.Size(684, 661);
            this.panelHraciaPlocha.TabIndex = 0;
            this.panelHraciaPlocha.Paint += new System.Windows.Forms.PaintEventHandler(this.panelHraciaPlocha_Paint);
            this.panelHraciaPlocha.MouseClick += new System.Windows.Forms.MouseEventHandler(this.panelHraciaPlocha_MouseClick);
            // 
            // ChessOkno
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 661);
            this.Controls.Add(this.panelHraciaPlocha);
            this.Name = "ChessOkno";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.SizeChanged += new System.EventHandler(this.Form1_SizeChanged);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelHraciaPlocha;
    }
}

